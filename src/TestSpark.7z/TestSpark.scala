import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import java.io.{File, FileInputStream}
import java.util.zip.GZIPInputStream
import scala.io.{BufferedSource, Source}
import scala.util.control.Breaks

object TestSpark {
  //    def main(args: Array[String]): Unit = {
  def main: Unit = {
    val sparkSession = SparkSession
      .builder()
      .master("local")
      .appName("test")
      .getOrCreate()
    val config = Map("header" -> "true", "delimiter" -> ",", "inferSchema" -> "true")
    val argGZ = "test00.csv.gz"
    val arg0 = "test.csv"
    val arg2 = "test02.csv"
    val sparkCsvObjGZ = sparkSession.read
      .options(config)
      .csv(argGZ)
    println("--" * 30)
    sparkCsvObjGZ.toDF().show()
    println("--" * 30)
    val sparkCsvObj = sparkSession.read
      .options(config)
      .csv(arg0)
    val df = sparkCsvObj.toDF(sparkCsvObj.columns.map(col => ("test_" + col)): _*)
    val sparkCsvObj02 = sparkSession.read
      .options(config)
      .csv(arg2)
    val df02 = sparkCsvObj02.toDF(sparkCsvObj02.columns.map(col => ("test_" + col)): _*)
    df.show()
    df02.show()
    val merge_df_df02 = df.join(
      //      df02, df.col("test_a").equalTo(df02.col("test_d")), joinType = "left")
      //https://www.cnblogs.com/rxingyue/p/7113235.html
      df02, df("test_a") === df02("test_d"), "left")
    merge_df_df02.show()
    merge_df_df02
      .coalesce(1)
      .write
      .mode(SaveMode.Overwrite)
      .option("header", "true")
      .csv("merge_test_test02.csv")

    merge_df_df02
      .select("test_a", "test_f")
      .toDF()
      .write
      .mode(SaveMode.Overwrite)
      .option("header", "true")
      .csv("simple.csv")
    val sparkCsvObj00 = sparkSession.read.options(config).csv("test00.csv")
    val df00 = sparkCsvObj00.toDF(sparkCsvObj00.columns.map(col => ("test_" + col)): _*)
    //https://www.cnblogs.com/rxingyue/p/7113235.html
    val merge_df_df00 = df.join(df00, Seq("test_a", "test_b"), "left")
    merge_df_df00.show()
    val merge_df_df00_ = merge_df_df00.withColumnRenamed("test_a-", "test_A").toDF()
    merge_df_df00_.show()

    val value_test_a = merge_df_df02.where("test_d is null").select("test_a").first().get(0)
    println(value_test_a)
    val value_test_d = merge_df_df02.where("test_d is null").select("test_d").first().get(0)
    println(value_test_d)
    println(value_test_d == null)

    merge_df_df02.na.fill(0.0).show()
    val map4naFill = Map("test_d" -> 0.0, "test_f" -> 1.0, "test_g" -> 2.0)
    merge_df_df02.na.fill(map4naFill).show()


    def setValue4test_g(x: Any, y: Any, z: Any): Double = {
      if (x == 4) {
        y.toString.toDouble
      } else {
        x.toString.toDouble * z.toString.toDouble
      }
    }
    //注册函数
    sparkSession
      .udf
      .register("setValue4test_g", setValue4test_g _)
    sparkSession
      .udf
      .register("setValue4test_g", setValue4test_g _)
    //注册成表
    merge_df_df02.createOrReplaceTempView("merge_df_df02")
    // 编写sql
    val tempDF: DataFrame = sparkSession.sql(
      """
        |select *,setValue4test_g(test_a,test_b,test_c) as setValue4test_g from merge_df_df02
        |""".stripMargin)

    tempDF.show()
    tempDF.withColumn("test_g", tempDF("setValue4test_g")).show()

    saveDfToCsv(merge_df_df02, "D:\\05大数据\\03 2021年尚硅谷大数据\\11.Spark\\test\\testOutput.csv", header = true)

    sparkSession.stop()
  }

  def saveDfToCsv(df: DataFrame, tsvOutput: String, sep: String = ",", header: Boolean = false): Unit = {
    val tmpParquetDir = "tmp"

    df.repartition(1)
      .write
      .mode(SaveMode.Overwrite)
      .format("com.databricks.spark.csv")
      .option("header", header.toString)
      .option("delimiter", sep)
      .save(tmpParquetDir)

    val dir = new File(tmpParquetDir)
    println(dir)
    val newFileRegex = tmpParquetDir + ".*part-0.*.csv"
    val tmpTsfFile = dir.listFiles.filter(_.toPath.toString.matches(newFileRegex))(0).toString
    (new File(tmpTsfFile)).renameTo(new File(tsvOutput))
    if (dir.toPath.toString.endsWith("tmp")) {
      dir.listFiles.foreach(
        f => {
          if (f.toPath.getParent.toString.endsWith("tmp")) {
            println("删除临时文件 => " + f)
            f.delete
          }
        })
      dir.delete
    }
  }

  //  def findPath(pattern: Pattern, pathList: List[String]): String = {
  //    pathList.filter(path => papath)
  //    return
  //  }
  def main(args: Array[String]): Unit = {
    val searchFile: File = new File("D:\\05大数据\\03 2021年尚硅谷大数据\\11.Spark\\test")
    val fileList: Array[File] =
      getFileList(searchFile)
    //      Array(new File("123"),new File("456"))
    println(fileList.mkString(",\n"))
    val filePath = fileList
      .find(file => file.toString
        //        .matches(".*02.cs.*"))
        .matches(".*1234544.*"))
      .getOrElse("No file path match pattern => " + ".*1234544.*")
      .toString
    println("*" * 50)
    println(filePath)
    println("*" * 50)
    main
    var updateFileListFlag = false
    val loop = new Breaks
    loop.breakable {

      for (file <- fileList) {
        if (!file.exists()) {
          updateFileListFlag = true
          loop.break()
        } else {
          println("Exists => " + file)
        }
      }
    }
    println("updateFileListFlag => " + updateFileListFlag)

    val inputStream = new FileInputStream("D:\\05大数据\\03 2021年尚硅谷大数据\\11.Spark\\test\\test00.csv.gz")
    val gzipFileSource: BufferedSource = Source.fromInputStream(new GZIPInputStream(inputStream))
    println(gzipFileSource.getLines.toList)


    gzipFileSource.close()
  }

  def getFileList(file: File): Array[File] = {
    val fileList = file.listFiles()
      .filter(_.isFile)
      .filter(f => f.toString.endsWith(".gz") || f.toString.endsWith(".csv"))
    fileList ++ file.listFiles().filter(_.isDirectory).flatMap(getFileList)
  }

  class RenameHadoopOutputFileName extends MultipleTextOutputFormat[String, String] {
    override def generateFileNameForKeyValue(key: String, value: String, name: String): String = key
  }
}
